package mk.ukim.finki.wp.jan2024g2.model.exceptions;

public class InvalidPostIdException extends RuntimeException {
}
