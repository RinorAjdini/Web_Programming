package mk.ukim.finki.wp.jan2024g2.repository;

public interface TagRepository {
}
