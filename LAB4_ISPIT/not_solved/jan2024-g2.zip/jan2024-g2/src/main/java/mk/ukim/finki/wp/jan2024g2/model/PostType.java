package mk.ukim.finki.wp.jan2024g2.model;

public enum PostType {
    ARTICLE,
    PAPER,
    POSTER,
}
