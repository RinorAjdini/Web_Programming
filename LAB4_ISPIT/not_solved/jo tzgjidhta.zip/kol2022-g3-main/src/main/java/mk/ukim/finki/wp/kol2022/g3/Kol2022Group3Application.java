package mk.ukim.finki.wp.kol2022.g3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kol2022Group3Application {

    public static void main(String[] args) {
        SpringApplication.run(Kol2022Group3Application.class, args);
    }

}
