package mk.ukim.finki.wp.kol2022.g3.repository;

public interface InterestRepository {
}
