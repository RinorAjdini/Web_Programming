package mk.ukim.finki.wp.kol2023.g1.repository;

public interface PlayerRepository {
}
