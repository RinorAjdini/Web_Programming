package mk.ukim.finki.wp.kol2023.g1.model;

public enum PlayerPosition {
    G,
    C,
    F
}
