package mk.ukim.finki.wp.kol2023.g1.service.impl;

public class PlayerServiceImpl {
}
