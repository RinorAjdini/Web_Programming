package mk.ukim.finki.wp.kol2023.g2.service.impl;

public class MovieServiceImpl {
}
