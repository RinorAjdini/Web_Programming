package mk.ukim.finki.wp.kol2023.g2.repository;

public interface DirectorRepository {
}
