package mk.ukim.finki.wp.exam.example.model;

public enum Role {
    ROLE_ADMIN
}
