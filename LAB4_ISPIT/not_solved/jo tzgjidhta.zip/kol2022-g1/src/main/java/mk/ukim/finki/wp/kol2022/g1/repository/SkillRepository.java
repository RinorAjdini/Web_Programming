package mk.ukim.finki.wp.kol2022.g1.repository;

public interface SkillRepository {
}
