package mk.ukim.finki.wp.jan2023.service.impl;

public class PartyServiceImpl {
}
