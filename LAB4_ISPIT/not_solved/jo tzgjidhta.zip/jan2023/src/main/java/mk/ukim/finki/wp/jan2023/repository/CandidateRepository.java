package mk.ukim.finki.wp.jan2023.repository;

public interface CandidateRepository {
}
