package mk.ukim.finki.wp.jan2023.model;

public enum Gender {
    MALE,
    FEMALE
}
