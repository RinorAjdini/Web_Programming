package mk.ukim.finki.wp.jan2022.g2.model.exceptions;

public class InvalidUserIdException extends RuntimeException {
}
