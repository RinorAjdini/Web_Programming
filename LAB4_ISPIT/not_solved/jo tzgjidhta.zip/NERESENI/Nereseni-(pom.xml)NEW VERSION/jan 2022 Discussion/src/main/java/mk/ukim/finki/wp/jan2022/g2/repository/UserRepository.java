package mk.ukim.finki.wp.jan2022.g2.repository;

public interface UserRepository
{

}
