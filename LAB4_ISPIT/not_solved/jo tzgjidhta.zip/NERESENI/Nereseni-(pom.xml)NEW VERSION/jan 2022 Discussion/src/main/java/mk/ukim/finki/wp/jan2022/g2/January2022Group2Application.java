package mk.ukim.finki.wp.jan2022.g2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class January2022Group2Application {

	public static void main(String[] args) {
		SpringApplication.run(January2022Group2Application.class, args);
	}

}
