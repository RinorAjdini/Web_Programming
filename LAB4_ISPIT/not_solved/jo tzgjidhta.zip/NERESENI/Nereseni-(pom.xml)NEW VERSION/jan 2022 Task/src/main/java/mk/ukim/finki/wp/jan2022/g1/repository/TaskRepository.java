package mk.ukim.finki.wp.jan2022.g1.repository;

public interface TaskRepository
{

}
