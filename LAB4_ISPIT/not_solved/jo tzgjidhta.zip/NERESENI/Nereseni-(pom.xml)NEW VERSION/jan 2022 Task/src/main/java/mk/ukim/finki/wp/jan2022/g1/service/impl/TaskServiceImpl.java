package mk.ukim.finki.wp.jan2022.g1.service.impl;

public class TaskServiceImpl
{

}
