package mk.ukim.finki.wp.june2022.g1.model.exceptions;

public class InvalidVirtualMachineIdException extends RuntimeException {
}
