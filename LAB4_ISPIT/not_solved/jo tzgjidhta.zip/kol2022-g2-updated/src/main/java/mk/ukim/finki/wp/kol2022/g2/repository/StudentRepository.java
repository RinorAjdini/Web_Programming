package mk.ukim.finki.wp.kol2022.g2.repository;

public interface StudentRepository {
}
